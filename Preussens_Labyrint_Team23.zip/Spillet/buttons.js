function controls(){
  document.getElementById('howto').src ="websidefiler/controls.png";
  document.getElementById("controls").style.backgroundColor = "#2FD474";
  document.getElementById("controls").style.color = "#23272a";
  document.getElementById("items").style.backgroundColor = "#13572F";
  document.getElementById("items").style.color = "#ffffff";
  document.getElementById("enemies").style.backgroundColor = "#13572F";
  document.getElementById("enemies").style.color = "#ffffff";
}
function items(){
  document.getElementById('howto').src ="websidefiler/items.png";
  document.getElementById("controls").style.backgroundColor = "#13572F";
  document.getElementById("controls").style.color = "#ffffff";
  document.getElementById("items").style.backgroundColor = "#2FD474";
  document.getElementById("items").style.color = "#23272a";
  document.getElementById("enemies").style.backgroundColor = "#13572F";
  document.getElementById("enemies").style.color = "#ffffff";
}
function enemies(){
  document.getElementById('howto').src ="websidefiler/enemies.png";
  document.getElementById("controls").style.backgroundColor = "#13572F";
  document.getElementById("controls").style.color = "#ffffff";
  document.getElementById("items").style.backgroundColor = "#13572F";
  document.getElementById("items").style.color = "#ffffff";
  document.getElementById("enemies").style.backgroundColor = "#2FD474";
  document.getElementById("enemies").style.color = "#23272a";
}
